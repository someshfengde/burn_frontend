const CTA = () => (
  <div> </div>
);


export default CTA;
