import ImageAnalyzer from '@/components/ImageAnalyzer';

export default function GeneratePage() {
  return (
    <div>
      <ImageAnalyzer />
    </div>
  );
}